/*
  To resolve some HBOOK entry points used in CLHEP !
*/
void hlimit_(){}

void hnoent_(){}
void hgnpar_(){}
void hgnf_(){}
void hdelet_(){}
void hbookn_(){}
void hfn_(){}
void hbook2_(){}
void hbook1_(){}
void hfill_(){}
void hx_(){}

void hcdir_(){}
void hmdir_(){}
void hddir_(){}

void hbprof_(){}

void hbname_(){}
void hbnt_(){}
void hfnt_(){}

void hropen_(){}
void hrout_(){}
void hrend_(){}

void hstati_(){}

void rzcl_(){}
void zitoh_(){}
void uhtoc_(){}

void rndm_(){}

/*commons :*/
int hcbook_[51];

/*minuit :*/
void mninit_(){}
void mnparm_(){}
void mnexcm_(){}
