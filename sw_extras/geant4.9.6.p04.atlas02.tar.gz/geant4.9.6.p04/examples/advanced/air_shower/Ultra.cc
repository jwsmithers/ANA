//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
// --------------------------------------------------------------
//                 GEANT 4 - ULTRA experiment example
// --------------------------------------------------------------
//
// Code developed by:
// B. Tome, M.C. Espirito-Santo
//
//   *******************************************************
//   *                  Ultra.cc
//   *******************************************************


#include "G4RunManager.hh"
#include "G4UImanager.hh"
#include "Randomize.hh"

#ifdef G4VIS_USE
#include "G4VisExecutive.hh"
#endif

#ifdef G4UI_USE
#include "G4UIExecutive.hh"
#endif

#include "UltraRunAction.hh"
#include "UltraDetectorConstruction.hh"
#include "UltraPrimaryGeneratorAction.hh"
#include "UltraPhysicsList.hh"
#include "UltraEventAction.hh"
//#include "CLHEP/Random/RanluxEngine.h"

int main(int argc,char** argv) {

//choose the Random engine from CLHEP 
//(lets use C++ implementation of Jame's RANLUX generator)
 
  CLHEP::HepRandom::setTheEngine(new CLHEP::RanluxEngine);
  G4RunManager* runManager = new G4RunManager;

  // UserInitialization classes - mandatory
  UltraDetectorConstruction* detector = new UltraDetectorConstruction;
  UltraPhysicsList* list = new UltraPhysicsList();
  runManager->SetUserInitialization(detector);
  runManager->SetUserInitialization(list);

  // UserAction classes - optional
  UltraPrimaryGeneratorAction* PrimGenAct = new UltraPrimaryGeneratorAction();
  runManager->SetUserAction(PrimGenAct);
  UltraRunAction* RunAct = new UltraRunAction();
  runManager->SetUserAction(RunAct);
  UltraEventAction* EvAct = new UltraEventAction(RunAct);
  runManager->SetUserAction(EvAct);

#ifdef G4VIS_USE
  // Visualization, if you choose to have it!
  G4VisManager* visManager = new G4VisExecutive;
  visManager->Initialize();
#endif

  //Initialize G4 kernel
  runManager->Initialize();

  // Get the Pointer to the UI Manager
  G4UImanager* UImanager = G4UImanager::GetUIpointer();

  // User interactions
  // Define (G)UI for interactive mode
  if(argc==1)
  {
#ifdef G4UI_USE
    G4UIExecutive* ui = new G4UIExecutive(argc, argv);
    ui->SessionStart();
    delete ui;
#endif
  }
  else
  // Batch mode
  {
    G4String command = "/control/execute ";
    G4String fileName = argv[1];
    UImanager->ApplyCommand(command+fileName);
  }

#ifdef G4VIS_USE
  delete  visManager;
#endif

  delete runManager;

  return 0;
}

